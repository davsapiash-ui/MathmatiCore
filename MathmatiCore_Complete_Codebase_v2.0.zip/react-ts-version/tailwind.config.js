/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        success: {
          DEFAULT: "hsl(var(--success))",
          foreground: "hsl(var(--success-foreground))",
        },
        warning: {
          DEFAULT: "hsl(var(--warning))",
          foreground: "hsl(var(--warning-foreground))",
        },
        ws: {
          bg: "hsl(var(--ws-bg))",
          surface: "hsl(var(--ws-surface))",
          surface2: "hsl(var(--ws-surface-2))",
          ink: "hsl(var(--ws-ink))",
          soft: "hsl(var(--ws-ink-soft))",
          accent: "hsl(var(--ws-accent))",
          accentSoft: "hsl(var(--ws-accent-soft))",
          blue: "hsl(var(--ws-blue))",
          blueSoft: "hsl(var(--ws-blue-soft))",
          teal: "hsl(var(--ws-teal))",
          success: "hsl(var(--ws-success))",
          danger: "hsl(var(--ws-danger))",
        },
        block: {
          unit: "var(--block-unit)",
          "unit-dark": "var(--block-unit-dark)",
          ten: "var(--block-ten)",
          "ten-dark": "var(--block-ten-dark)",
          hundred: "var(--block-hundred)",
          "hundred-dark": "var(--block-hundred-dark)",
          thousand: "var(--block-thousand)",
          "thousand-dark": "var(--block-thousand-dark)",
        },
      },
      fontFamily: {
        display: ["Rubik", "Heebo", "sans-serif"],
        body: ["Heebo", "Assistant", "sans-serif"],
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      transitionDuration: {
        '2500': '2500ms',
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}

