import { useEffect, useRef } from 'react';
import { driver } from 'driver.js';
import 'driver.js/dist/driver.css';

// In-memory state (Zero Local Storage Policy)
const isWebdriver = typeof navigator !== 'undefined' && navigator.webdriver;
let teacherTourSeen = typeof window !== 'undefined' && ((window as any).__E2E_BYPASS_TOUR__ === true || isWebdriver);

export function useTeacherTour() {
  const driverObj = useRef<any>(null);

  useEffect(() => {
    driverObj.current = driver({
      showProgress: true,
      animate: true,
      allowClose: false,
      overlayColor: 'rgba(15, 23, 42, 0.75)',
      nextBtnText: 'הבא',
      prevBtnText: 'הקודם',
      doneBtnText: 'הבנתי, בוא נתחיל!',
      progressText: '{{current}} מתוך {{total}}',
      popoverClass: 'ws-tour-popover font-display',
      steps: [
        {
          element: '#tour-tab-clustering',
          popover: {
            title: 'מיפוי כיתתי',
            description: 'כאן תוכלי לראות בזמן אמת את פילוג הכיתה לפי מיומנויות, עם אפשרות לחלק למשימות מותאמות.',
            side: 'left',
            align: 'start'
          }
        },
        {
          element: '#tour-tab-alerts',
          popover: {
            title: 'רדאר סמוי',
            description: 'כאן תקבלי התראות בזמן אמת על תלמידים שמראים סימני תסכול או היסוס בזמן פתרון משימה.',
            side: 'left',
            align: 'start'
          }
        },
        {
          element: '#tour-tab-reports',
          popover: {
            title: 'דו"חות אישיים',
            description: 'במסך זה ניתן לצפות בפרופיל של כל תלמיד בנפרד ולצפות בשחזורים מדויקים של פעולותיו.',
            side: 'left',
            align: 'start'
          }
        },
        {
          element: '#tour-tab-chat',
          popover: {
            title: 'תקשורת אישית',
            description: 'מכאן ניתן לנהל צ׳אט עם התלמידים, לשלוח רמזים, ולראות הודעות נכנסות.',
            side: 'left',
            align: 'start'
          }
        },
        {
          element: '#tour-tab-approvals',
          popover: {
            title: 'אישור משימות AI',
            description: 'משימות שנבדקו על ידי מנוע ה-AI ימתינו לאישורך כאן לפני שהתלמיד יוכל להמשיך.',
            side: 'left',
            align: 'start'
          }
        },
        {
          element: '#tour-tab-class_management',
          popover: {
            title: 'ניהול כיתה',
            description: 'צפייה בסטטוס ההתקדמות של התלמידים, נתוני אבחון ואפשרויות איפוס במידת הצורך.',
            side: 'left',
            align: 'start'
          }
        }
      ]
    });
  }, []);

  const startTour = () => {
    if (driverObj.current) {
      driverObj.current.drive();
    }
  };

  useEffect(() => {
    if (!teacherTourSeen) {
      // Small delay to ensure UI is mounted
      const timer = setTimeout(() => {
        startTour();
        teacherTourSeen = true;
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  return { startTour };
}
