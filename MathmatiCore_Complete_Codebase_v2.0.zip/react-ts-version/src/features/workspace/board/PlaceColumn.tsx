import { useEffect } from 'react';
import { useDroppable, useDndContext } from '@dnd-kit/core';
import { motion, useAnimationControls, AnimatePresence } from 'framer-motion';
import { MAX_VISIBLE_BLOCKS, PLACE_NAMES_HE, type Place } from '@/core/placeValue';
import { useWorkspaceStore } from '@/application/useWorkspaceStore';
import { DienesBlock } from './DienesBlock';

/** Per-place functional colors (vanilla workspace.css 346–375). */
const COLUMN_COLORS: Record<Place, { header: string; border: string; tint: string; headerBg: string }> = {
  units: { header: 'var(--block-unit-dark)', border: 'var(--block-unit)', tint: 'rgba(245,158,11,0.08)', headerBg: 'rgba(245,158,11,0.14)' },
  tens: { header: 'var(--block-ten-dark)', border: 'var(--block-ten)', tint: 'rgba(16,185,129,0.08)', headerBg: 'rgba(16,185,129,0.14)' },
  hundreds: { header: 'var(--block-hundred-dark)', border: 'var(--block-hundred)', tint: 'rgba(59,130,246,0.08)', headerBg: 'rgba(59,130,246,0.14)' },
  thousands: { header: 'var(--block-thousand-dark)', border: 'var(--block-thousand)', tint: 'rgba(239,68,68,0.08)', headerBg: 'rgba(239,68,68,0.14)' },
};

export function PlaceColumn({ place }: { place: Place }) {
  const count = useWorkspaceStore((s) => s.counts[place]);
  const errorPlace = useWorkspaceStore((s) => s.errorPlace);
  const errorNonce = useWorkspaceStore((s) => s.errorNonce);
  const focusedPlace = useWorkspaceStore((s) => s.focusedPlace);
  const isASD = useWorkspaceStore((s) => s.isASD);
  const removeBlockClick = useWorkspaceStore((s) => s.removeBlockClick);
  const sessionNumber = useWorkspaceStore((s) => s.sessionNumber);

  const { setNodeRef, isOver } = useDroppable({
    id: `column-${place}`,
    data: { kind: 'column', place },
  });

  const { active } = useDndContext();
  const activePlace = active?.data.current?.place as Place | undefined;
  
  // Show preview of 10 units when dragging a tens rod over the units column
  const isPreviewingDecomp = isOver && place === 'units' && activePlace === 'tens';

  const scaffoldFadeLevel = useWorkspaceStore((s) => s.scaffoldFadeLevel);

  const colors = COLUMN_COLORS[place];
  const renderCount = Math.min(count, MAX_VISIBLE_BLOCKS);
  const isError = errorPlace === place;
  const isDimmed = (isASD || sessionNumber === 6) && focusedPlace !== null && focusedPlace !== place;

  // Constraint-error shake (vanilla .constraint-error, 400ms). errorNonce retriggers repeats.
  const shakeControls = useAnimationControls();
  useEffect(() => {
    if (isError) {
      shakeControls.start({ x: [0, -8, 8, -6, 6, -3, 3, 0], transition: { duration: 0.4 } });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [errorNonce]);

  const isHighlighted = scaffoldFadeLevel === 0;

  return (
    <motion.div
      id={place === 'units' ? 'tour-column-units' : undefined}
      animate={shakeControls}
      className={`flex-1 min-w-0 flex flex-col rounded-2xl border-2 transition-all duration-300 ${
        isHighlighted ? 'border-solid' : 'border-dashed'
      } ${
        isDimmed ? 'opacity-20 pointer-events-none' : ''
      } ${isOver ? 'animate-[pulse_1.5s_ease-in-out_infinite]' : ''}`}
      style={{
        borderColor: isOver 
          ? colors.border 
          : isHighlighted 
            ? 'hsl(var(--ws-ink) / 0.22)' 
            : 'hsl(var(--ws-surface-2) / 0.75)',
        backgroundColor: isOver || isError ? colors.tint : 'hsl(var(--ws-surface))',
        boxShadow: isOver 
          ? `0 0 0 4px ${colors.tint}` 
          : isHighlighted 
            ? '0 4px 14px -6px rgba(0,0,0,0.06)' 
            : '0 2px 8px -6px rgba(0,0,0,0.02)',
      }}
      aria-label={`טור ${PLACE_NAMES_HE[place]}`}
    >
      <div
        className="relative flex items-center justify-center py-2.5 font-display font-extrabold text-lg border-b-[3px] rounded-t-[14px]"
        style={{ color: colors.header, backgroundColor: colors.headerBg, borderColor: colors.header }}
      >
        <span>{PLACE_NAMES_HE[place]}</span>
        <span
          aria-live="polite"
          className={`absolute left-3 min-w-[22px] h-[22px] px-1 rounded-full text-xs font-black text-white inline-flex items-center justify-center transition-all ${
            count > 0 ? 'opacity-100 scale-100' : 'opacity-0 scale-50'
          }`}
          style={{ backgroundColor: colors.header }}
        >
          {count > 0 ? count : ''}
        </span>
      </div>

      <div
        ref={setNodeRef}
        id={`column-${place}`}
        role="group"
        aria-label={`אזור גרירה — ${PLACE_NAMES_HE[place]}`}
        className="flex-1 flex flex-row flex-wrap content-start justify-center items-start gap-1 p-2 min-h-[150px] overflow-y-auto overflow-x-hidden no-scrollbar"
      >

        <AnimatePresence>
        {Array.from({ length: renderCount }).map((_, i) => {
          let overlapStyle: React.CSSProperties = { zIndex: i };
          if (i > 0) {
            if (place === 'hundreds') {
              overlapStyle.marginRight = '-30px';
              overlapStyle.marginTop = '-5px';
            } else if (place === 'thousands') {
              overlapStyle.marginRight = '-40px';
              overlapStyle.marginTop = '-10px';
            } else if (place === 'tens') {
              overlapStyle.marginRight = '-15px';
              overlapStyle.marginTop = '0px';
            }
          }

          return (
            <motion.div 
              key={`${place}-${i}`} 
              style={overlapStyle} 
              className="relative transition-all"
              exit={{ opacity: 0, scale: 1.3, y: -10, transition: { duration: 0.25 } }}
            >
              <DienesBlock
                id={`col-${place}-${i}`}
                place={place}
                source="column"
                onRemove={() => removeBlockClick(place)}
                noEnter={i < renderCount - 1}
              />
            </motion.div>
          );
        })}

        {isPreviewingDecomp && Array.from({ length: 10 }).map((_, i) => (
          <motion.div
            key={`preview-units-${i}`}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 0.5, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            className="relative transition-all pointer-events-none"
            style={{ zIndex: renderCount + i }}
          >
            <DienesBlock
              id={`preview-units-${i}`}
              place="units"
              source="column"
              noEnter={true}
            />
          </motion.div>
        ))}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
