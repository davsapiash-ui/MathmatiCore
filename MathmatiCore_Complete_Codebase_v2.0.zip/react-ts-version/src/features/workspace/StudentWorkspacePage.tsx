import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  MouseSensor,
  TouchSensor,
  pointerWithin,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from '@dnd-kit/core';
import { useNavigate } from 'react-router-dom';
import type { DragSource, Place } from '@/core/placeValue';
import { useWorkspaceStore, getActiveTasks, type SessionNumber } from '@/application/useWorkspaceStore';
import { useSettingsStore } from '@/application/useSettingsStore';
import { useAuthStore } from '@/application/useAuthStore';
import { database, authReady } from '@/infrastructure/firebase';
import { ref, push, onValue, remove, get, set, update } from 'firebase/database';
import { useChatStore } from '@/application/useChatStore';
import { motion, AnimatePresence } from 'framer-motion';
import { getCurrentQTask, isSubtaskActive } from '@/core/qmatrixFlow';
import { PlaceValueBoard } from './board/PlaceValueBoard';

import { DienesBlock } from './board/DienesBlock';
import { WorkspaceTopbar } from './WorkspaceTopbar';
import { TaskCard } from './tasks/TaskCard';
import { FeedbackToast } from './overlays/FeedbackToast';
import { HelpOverlays } from './overlays/HelpOverlays';
import { ReflectionScreen } from './ReflectionScreen';
import { Session8ReflectionScreen } from '@/presentation/components/student/Session8ReflectionScreen';
import { firebaseSyncService } from '@/infrastructure/services/FirebaseSyncService';
import { useStore } from '@/application/useStore';

import { StudentChatOverlay } from './overlays/StudentChatOverlay';
import { AdditionHelper } from './board/AdditionHelper';

import { SocraticEngine } from '@/infrastructure/services/SocraticEngine';
import { AuditLogger } from '@/infrastructure/services/AuditLogger';
import { GraphicOrganizerHint } from './overlays/GraphicOrganizerHint';
import { useCognitiveHesitationRadar } from '@/application/useCognitiveHesitationRadar';

/**
 * מרחב הפעילות של התלמיד — חוויית מסך מלא ממוקדת (100vh, ללא גלילה, ללא טיימרים).
 * פריסה לפי מקור האמת הוונילי: כרטיס משימה (ימין) / טבלת ערך המקום (שמאל), 50/50.
 */
export function StudentWorkspacePage() {
  const [searchParams] = useSearchParams();
  const meetingRaw = parseInt(searchParams.get('meeting') ?? '1', 10);
  const meeting = (Number.isNaN(meetingRaw) ? 1 : Math.min(8, Math.max(1, meetingRaw))) as SessionNumber;

  const navigate = useNavigate();
  const { isASDMode } = useSettingsStore();
  const initSession = useWorkspaceStore((s) => s.initSession);
  const restoreSession = useWorkspaceStore((s) => s.restoreSession);
  const applyDrop = useWorkspaceStore((s) => s.applyDrop);
  const sessionNumber = useWorkspaceStore((s) => s.sessionNumber);
  const flowStatus = useWorkspaceStore((s) => s.flowStatus);
  const qflow = useWorkspaceStore((s) => s.qflow);
  const aiSocraticHint = useWorkspaceStore((s) => s.aiSocraticHint);
  const user = useAuthStore((s) => s.user);

  const isTimeExceeded = useWorkspaceStore((s) => s.isTimeExceeded);
  const awaitingNext = useWorkspaceStore((s) => s.awaitingNext);

  // Soft 25-minute Timer Check
  useEffect(() => {
    const interval = setInterval(() => {
      useWorkspaceStore.getState().checkTimeExceeded();
    }, 10000); // Check every 10 seconds
    return () => clearInterval(interval);
  }, []);

  // Start telemetry session so the radar tracker is active
  useEffect(() => {
    if (!user?.uid) return;
    return () => {
    };
  }, [user?.uid]);

  const [teacherHint, setTeacherHint] = useState<string | null>(null);

  useEffect(() => {
    if (!user?.uid) return;
    const hintRef = ref(database, `users/students/${user.uid}/teacher_hint`);
    const unsub = onValue(hintRef, (snap) => {
      if (snap.exists()) {
        const hintData = snap.val();
        if (hintData && hintData.message) {
          setTeacherHint(hintData.message);
        }
      }
    });
    return () => unsub();
  }, [user?.uid]);

  const handleAcknowledgeHint = async () => {
    if (!user?.uid) return;
    const hintRef = ref(database, `users/students/${user.uid}/teacher_hint`);
    await remove(hintRef);

    let resolvedTeacherId: string = '039604483'; // default fallback
    try {
      const studentSnap = await get(ref(database, `users/students/${user.uid}`));
      const classId = studentSnap.val()?.classId;
      if (classId) {
        const classSnap = await get(ref(database, `classes/${classId}`));
        const fbTeacherId = classSnap.val()?.teacherId;
        if (fbTeacherId && typeof fbTeacherId === 'string') resolvedTeacherId = fbTeacherId;
      }
    } catch (e) {
      console.error(e);
    }

    const chatStore = useChatStore.getState();
    chatStore.sendMessage(user.uid as string, (user as any).name || (user as any).displayName || 'תלמיד', resolvedTeacherId, `ראיתי את הרמז ("${teacherHint}"). תודה!`);
    
    setTeacherHint(null);
  };

  const [activeDrag, setActiveDrag] = useState<{ place: Place; source: DragSource; renderPlace?: Place } | null>(null);

  // הרדאר השקט — covert monitoring for the teacher dashboard; nothing student-visible.

  // Session done (meeting 4 end) → back to the hub.
  // NOTE: qMatrixResults/traceData are written ONCE, at the right moment — the
  // ReflectionScreen at the end of meeting 2. A second write here used wrong result
  // keys with correct=true defaults and silently overwrote real diagnostics — removed.
  useEffect(() => {
    if (flowStatus === 'sessionDone') {
      navigate('/hub');
    }
  }, [flowStatus, navigate]);

  // Keyboard: Enter = proceed (outside inputs), Ctrl/Cmd+Z = undo (vanilla app.js 1412–1416).
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const inInput = (e.target as HTMLElement)?.tagName === 'INPUT';
      if (e.key === 'Enter' && !inInput) {
        useWorkspaceStore.getState().proceed();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        useWorkspaceStore.getState().undo();
      }
    };
    
    const onVisibilityChange = () => {
      if (document.hidden) {
        const studentId = useAuthStore.getState().user?.uid;
        if (studentId) {
          AuditLogger.log('TAB_ESCAPE', studentId, 'Student switched to another tab or window');
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    document.addEventListener('visibilitychange', onVisibilityChange);
    
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, []);

  // RRWeb recording with batching
  useEffect(() => {
    let stopRecording: (() => void) | undefined;
    let eventsQueue: any[] = [];
    let flushInterval: any;
    let cancelled = false;
    const sessionId = Date.now().toString();

    const uid = user?.uid;
    if (!uid) return;

    // Save this session ID so the dashboard knows what to fetch without OOM
    update(ref(database, `users/students/${uid}`), { latestTelemetrySessionId: sessionId }).catch(console.error);

    const flushTelemetry = () => {
      if (eventsQueue.length > 0) {
        const batch = [...eventsQueue];
        eventsQueue = [];
        const newChunkRef = push(ref(database, `users/students/${uid}/telemetry_sessions/${sessionId}/chunks`));
        const chunkKey = newChunkRef.key;
        if (chunkKey) {
          set(newChunkRef, JSON.stringify(batch)).catch(err => console.error('Telemetry push failed:', err));
          
          update(ref(database, `users/students/${uid}/telemetry_sessions/${sessionId}/metadata`), {
            [chunkKey]: {
              startTime: batch[0].timestamp,
              endTime: batch[batch.length - 1].timestamp
            }
          });
        }
      }
    };

    // Load rrweb asynchronously
    (async () => {
      const [rrweb] = await Promise.all([
        import('rrweb')
      ]);

      if (cancelled) return;

      const authOk = await authReady;
      if (!authOk || cancelled) return;

      const rrwebAny = rrweb as any;
      const recordFn = rrweb.record || (rrwebAny.default && rrwebAny.default.record) || rrwebAny;
      if (typeof recordFn !== 'function') {
        console.error('rrweb.record is not a function:', rrweb);
        return;
      }

      stopRecording = recordFn({
        emit(event: any) {
          eventsQueue.push(event);
        },
        sampling: {
          mousemove: true,
          mouseInteraction: true,
          scroll: 150,
          input: 'last',
        }
      });

      flushInterval = setInterval(flushTelemetry, 2000);
      window.addEventListener('beforeunload', flushTelemetry);
    })();

    return () => {
      cancelled = true;
      if (stopRecording) stopRecording();
      if (flushInterval) clearInterval(flushInterval);
      window.removeEventListener('beforeunload', flushTelemetry);
      flushTelemetry();
    };
  }, [user?.uid]);



  // Pedagogical Radar
  useCognitiveHesitationRadar({ isActive: true });
  const [isInitializing, setIsInitializing] = useState(true);
  const [pendingApproval, setPendingApproval] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [isAdditionHelperOpen, setIsAdditionHelperOpen] = useState(false);

  // Reset initialization when meeting changes
  useEffect(() => {
    setIsInitialized(false);
  }, [meeting]);

  // Retrieve saved progress from Firebase (synced into useStore)
  const students = useStore((s) => s.students);
  const firebaseLoaded = useStore((s) => s.firebaseLoaded);
  const myData = user?.uid ? students[user.uid] : null;
  const isAdditionBoardEnabled = myData?.additionBoardEnabled ?? false;

  // --- PRD Section 4.5: Physical Override Teardown Cleanup Pipeline ---
  useEffect(() => {
    if (!user?.uid) return;
    
    const overrideRef = ref(database, `sessions/${user.uid}/physical_override`);
    let previousOverrideState = false;
    
    const unsubscribe = onValue(overrideRef, (snapshot) => {
      const isOverrideActive = snapshot.val() === true;
      
      // Listen for transition from TRUE to FALSE
      if (previousOverrideState && !isOverrideActive) {
        console.log("Physical Override Teardown: Cleanup Pipeline triggered.");
        const store = useWorkspaceStore.getState();
        // 1. Restart hesitation timer by toggling keyboard state
        store.lockKeyboard();
        // 2. Validate current block state against target state (CRA Bridge).
        // The proceed() call handles the mathematical comparison.
        store.proceed(); 
      }
      
      previousOverrideState = isOverrideActive;
    });

    return () => unsubscribe();
  }, [user?.uid]);

  useEffect(() => {
    if (!firebaseLoaded || isInitialized) return;
    let cancelled = false;

    if (meeting === 3) {
      setIsInitializing(true);
      // Any failure in this async chain must NOT strand the student on the loading
      // screen — the outer .catch falls back to the standard session tasks.
      (async () => {
        if (cancelled) return;
        const username = useAuthStore.getState().user?.uid;
        if (!username) {
          initSession(meeting, isASDMode, null, 0);
          setIsInitialized(true);
          setIsInitializing(false);
          return;
        }
        const tasks = await SocraticEngine.getApprovedTasks(username);
        if (cancelled) return;
        if (tasks) {
          const canRestore = myData?.workspaceState?.sessionNumber === meeting && myData?.workspaceState?.flowStatus === 'task';
          if (canRestore && myData?.workspaceState) {
            restoreSession(myData.workspaceState);
          } else {
            initSession(meeting, isASDMode, tasks, 0);
          }
        } else {
          // Pending teacher approval — blocking screen with a way back to the hub.
          setPendingApproval(true);
        }
        setIsInitialized(true);
        setIsInitializing(false);
      })().catch(() => {
        if (cancelled) return;
        const canRestore = myData?.workspaceState?.sessionNumber === meeting && myData?.workspaceState?.flowStatus === 'task';
        if (canRestore && myData?.workspaceState) {
          restoreSession(myData.workspaceState);
        } else {
          initSession(meeting, isASDMode, null, 0);
        }
        setIsInitialized(true);
        setIsInitializing(false);
      });
    } else {
      const canRestore = myData?.workspaceState?.sessionNumber === meeting && myData?.workspaceState?.flowStatus === 'task';
      if (canRestore && myData?.workspaceState) {
        restoreSession(myData.workspaceState);
      } else {
        initSession(meeting, isASDMode, null, 0);
      }
      setIsInitialized(true);
      setIsInitializing(false);
    }
    return () => {
      cancelled = true;
    };
    // isASDMode intentionally not a dependency: mid-session toggling must not reset the student's work.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [meeting, firebaseLoaded, isInitialized, myData, initSession, restoreSession]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(MouseSensor, { activationConstraint: { distance: 5 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 250, tolerance: 5 } })
  );

  const handleDragStart = (event: DragStartEvent) => {
    const data = event.active.data.current as { source: DragSource; place: Place; renderPlace?: Place } | undefined;
    if (data) setActiveDrag({ place: data.place, source: data.source, renderPlace: data.renderPlace });

    // Semantic Event Injection
    const studentId = useAuthStore.getState().user?.uid;
    if (studentId && data) {
      const s = useWorkspaceStore.getState();
      const task = getActiveTasks(s)[s.standardTaskIdx] || null;
      useStore.getState().logSemanticEvent(studentId, {
        action: 'drag_started',
        element: data.source === 'palette' ? 'palette_block' : `${data.place}_block`,
        context: 'User picked up a block',
        ...(task?.targetNode ? { q_matrix_node: task.targetNode } : {}),
        state_snapshot: `Units: ${s.counts.units}, Tens: ${s.counts.tens}, Hundreds: ${s.counts.hundreds}, Thousands: ${s.counts.thousands}`
      });
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveDrag(null);
    const data = event.active.data.current as { source: DragSource; place: Place } | undefined;
    const over = event.over?.data.current as { kind: 'column'; place: Place } | { kind: 'trash' } | undefined;
    if (!data || !over) return;
    applyDrop({
      source: data.source,
      sourcePlace: data.place,
      target: over.kind === 'trash' ? { kind: 'trash' } : { kind: 'column', place: over.place },
    });
  };

  // All 5 diagnostic tasks done → reflection (icons, no numeric grades).
  // After every hook so React's hook order stays stable.
  if (flowStatus === 'reflection') {
    if (sessionNumber === 8) {
      return <Session8ReflectionScreen 
        metrics={{ fastestTaskType: 'כפל פי 10 ו-100', slowestTaskType: 'כפל פי 20 ו-30' }}
        onComplete={(focusArea) => {
          if (user?.uid) {
            firebaseSyncService.syncRouteRecommendation(user.uid, focusArea);
          }
          navigate('/hub');
        }}
      />;
    }
    return <ReflectionScreen />;
  }
  
  if (isTimeExceeded && !awaitingNext && flowStatus === 'task') {
    return (
      <div dir="rtl" className="h-screen w-full flex flex-col items-center justify-center bg-ws-bg text-ws-ink font-body p-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-ws-surface p-12 rounded-3xl shadow-2xl max-w-2xl text-center border border-ws-surface2 flex flex-col items-center"
        >
          <div className="text-7xl mb-8 animate-bounce">🐝</div>
          <h2 className="text-3xl font-black mb-6 text-ws-ink leading-tight">
            איזו עבודה נפלאה עשית היום!
            <br />
            עכשיו זה הזמן להניח את המסך ולדבר עם המורה שרה.
          </h2>
          <p className="text-ws-soft text-lg mb-8 font-medium">
            כל הכבוד על ההתמדה והמאמץ. אנחנו גאים בך!
          </p>
          <button 
            onClick={() => navigate('/hub')}
            className="px-10 py-4 bg-ws-accent text-white font-bold text-xl rounded-full shadow-md hover:brightness-105 transition-all active:scale-95"
          >
            המשך
          </button>
        </motion.div>
      </div>
    );
  }

  if (isInitializing) {
    return (
      <div dir="rtl" className="h-screen w-full flex flex-col items-center justify-center bg-ws-bg text-ws-ink font-body">
        <div className="animate-spin text-4xl mb-4">⏳</div>
        <h2 className="text-xl font-bold">טוען את המשימות המותאמות שלך...</h2>
      </div>
    );
  }

  if (pendingApproval) {
    return (
      <div dir="rtl" className="h-screen w-full flex flex-col items-center justify-center bg-ws-bg text-ws-ink font-body p-6">
        <div className="bg-ws-surface p-10 rounded-3xl shadow-xl max-w-md text-center border border-ws-surface2">
          <div className="text-5xl mb-6">🧑‍🏫</div>
          <h2 className="text-2xl font-bold mb-4 text-ws-ink">המורה בודק את המסלול שלך</h2>
          <p className="text-ws-soft mb-8">
            סיימת את שלב האבחון בהצלחה! כעת, המורה עובר על התוצאות ומאשר את המשימות המותאמות במיוחד עבורך. אפשר לחזור מאוחר יותר.
          </p>
          <button 
            onClick={() => navigate('/hub')}
            className="w-full py-4 bg-ws-accent text-white font-bold rounded-2xl hover:brightness-105 transition-all"
          >
            חזרה לעמוד הראשי
          </button>
        </div>
      </div>
    );
  }

  return (
    <DndContext sensors={sensors} collisionDetection={pointerWithin} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
      <div
      dir="rtl"
      className="h-[100dvh] w-full overflow-hidden font-body text-ws-ink flex flex-col relative bg-ws-bg"
    >
      {/* Flat vector background shapes — playful world energy, zero visual noise */}
        <div aria-hidden="true" className="absolute inset-0 pointer-events-none overflow-hidden animate-breathe">
          <div className="absolute -top-24 -left-24 w-[420px] h-[420px] rounded-full bg-indigo-500/5 mix-blend-multiply dark:mix-blend-screen" />
          <div className="absolute -bottom-32 -right-20 w-[380px] h-[380px] rounded-full bg-teal-500/5 mix-blend-multiply dark:mix-blend-screen" />
          <div className="absolute top-[30%] right-[42%] w-16 h-16 rounded-2xl rotate-12 bg-blue-500/5 mix-blend-multiply dark:mix-blend-screen" />
        </div>

        <WorkspaceTopbar />

        {/* Main 50/50 workspace (or centered in Session 8) */}
        <main className={`flex flex-row flex-1 overflow-hidden p-5 gap-5 max-w-[1600px] mx-auto w-full box-border ${sessionNumber === 8 ? 'justify-center items-center' : ''}`}>
          {/* Task card */}
          <div className={`flex-1 min-h-0 min-w-0 flex flex-col ${sessionNumber === 8 ? 'max-w-3xl flex-none h-auto' : ''}`}>
            <TaskCard />
          </div>

          {/* Place-value board (left in RTL, hidden in Session 8) */}
          {sessionNumber !== 8 && (
            <PlaceValueBoard />
          )}
        </main>

        <AnimatePresence>
          {teacherHint && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl border-4 border-ws-accent text-center"
              >
                <div className="text-5xl mb-4">👨‍🏫</div>
                <h2 className="text-2xl font-black font-display text-ws-ink mb-4">הודעה מהמורה</h2>
                <p className="text-xl text-ws-ink font-medium mb-8 bg-blue-50 p-6 rounded-2xl leading-relaxed">
                  "{teacherHint}"
                </p>
                <button
                  onClick={handleAcknowledgeHint}
                  className="w-full h-14 rounded-2xl bg-ws-accent text-white font-black text-xl shadow-lg hover:bg-blue-600 hover:scale-[1.02] active:scale-95 transition-all"
                >
                  ראיתי, תודה!
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <FeedbackToast />
        <HelpOverlays />
        <StudentChatOverlay />
        
        {aiSocraticHint && (
          <GraphicOrganizerHint 
            hint={aiSocraticHint} 
            onClose={() => useWorkspaceStore.setState({ aiSocraticHint: null, helpState: 'closed' })}
            onSelectOption={(id) => {
              const state = useWorkspaceStore.getState();
              if (state.keyboardState === 'SOCRATIC_ONLY') {
                // If the backend doesn't specify a correct choice, any answer unlocks it.
                // If we add `correctChoiceId` in the future, we can validate it here.
                if (!(aiSocraticHint as any).correctChoiceId || (aiSocraticHint as any).correctChoiceId === id) {
                  state.unlockKeyboard();
                }
              }
            }}
          />
        )}

        {isAdditionBoardEnabled && (
          <div className="fixed bottom-20 left-4 z-50 flex flex-col items-end gap-2" dir="rtl">
            <AnimatePresence>
              {isAdditionHelperOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 20, scale: 0.95 }}
                  className="mb-2 shadow-2xl"
                >
                  <AdditionHelper />
                </motion.div>
              )}
            </AnimatePresence>
            <button
              onClick={() => setIsAdditionHelperOpen(!isAdditionHelperOpen)}
              className="bg-ws-accent text-white font-bold px-4 py-3 rounded-full shadow-lg hover:bg-ws-accent/90 transition-all flex items-center gap-2 border border-ws-accent/20"
            >
              <span>🧮</span>
              <span>לוח עזר לחיבור</span>
            </button>
          </div>
        )}
      </div>

      <DragOverlay dropAnimation={{ duration: 250, easing: 'cubic-bezier(0.18, 0.67, 0.6, 1.22)' }}>
        {activeDrag ? (
          // 15% smaller than the old 1.10 per user request — the dragged block must not dwarf the board
          <div className="scale-[0.93] rotate-2 opacity-90 drop-shadow-2xl">
            <DienesBlock id="drag-overlay" place={activeDrag.renderPlace ?? activeDrag.place} source={activeDrag.source} isOverlay />
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
