import { useWorkspaceStore } from '@/application/useWorkspaceStore';
import type { QMatrixTask } from '@/core/QMatrix';
import type { QMatrixFlowState } from '@/core/qmatrixFlow';
import { getEffectiveChoices, getEffectiveNumber, getEffectiveRange } from '@/core/qmatrixFlow';
import { ChoiceList } from './ChoiceList';
import { UdlSpeechButton } from '@/presentation/design-system/UdlSpeechButton';
import { InlineMath } from 'react-katex';
import 'katex/dist/katex.min.css';
import { getValue } from '@/core/placeValue';
import { motion } from 'framer-motion';
import { VisualGraphicOrganizer } from './VisualGraphicOrganizer';

/**
 * "מעוף הדבורה" — תת-משימת אבחון לאחור: גרסה פשוטה יותר של המשימה שנכשלה.
 * לתלמיד זה נראה כמו עוד משימה רגילה (שקוף לחלוטין, ללא תיוג).
 * Rendering per vanilla renderBackwardDiagnosis (app.js 876–937).
 */
export function BackwardDiagnosisView({ task, qflow, isASD }: { task: QMatrixTask; qflow: QMatrixFlowState; isASD: boolean }) {
  const diag = task.backwardDiagnosis;
  const demoUngroup = useWorkspaceStore((s) => s.demoUngroup);
  const probeAnswer = useWorkspaceStore((s) => s.probeAnswer);
  const setProbeAnswer = useWorkspaceStore((s) => s.setProbeAnswer);
  const q3Reps = useWorkspaceStore((s) => s.q3Reps);
  const addRepresentation = useWorkspaceStore((s) => s.addRepresentation);
  const done = q3Reps.length >= 2;

  if (!diag) return null;

  const instruction = diag.subtaskInstructionHe ?? diag.probeInstructionHe ?? '';
  const effNumber = getEffectiveNumber(task, qflow, isASD);
  const choices = getEffectiveChoices(task, qflow);

  const effProbeA = isASD && diag.asdProbeA !== undefined ? diag.asdProbeA : diag.probeA;
  const effProbeB = isASD && diag.asdProbeB !== undefined ? diag.asdProbeB : diag.probeB;

  return (
    <motion.div 
      initial={{ scale: 0.9, opacity: 0, y: 20 }}
      animate={{ scale: 1, opacity: 1, y: 0 }}
      transition={{ type: 'spring', stiffness: 200, damping: 15 }}
      className="flex flex-col gap-4 mt-2 bg-yellow-50/80 p-6 rounded-[2rem] border-4 border-yellow-200/50 shadow-inner"
    >
      <div className="flex items-center gap-4 mb-2">
        <div className="w-16 h-16 rounded-full bg-white shadow-md flex items-center justify-center text-4xl animate-bounce">
          🤖
        </div>
        <div className="flex-1">
          <h2 className="text-2xl font-display font-black text-amber-600">אוי, בוט הסתבך!</h2>
          <p className="text-amber-800/80 font-medium">בואו נעזור לרובוט שלנו לפתור את השלב הזה כדי שיוכל להמשיך...</p>
        </div>
      </div>

      {instruction && (
        <div className="flex items-start gap-3 bg-white/70 p-4 rounded-2xl">
          <p className="text-lg font-bold text-ws-ink leading-relaxed flex-1">{instruction}</p>
          <UdlSpeechButton text={instruction} />
        </div>
      )}

      {/* Choice-based subtask (task1: zero as place-holder) */}
      {diag.subtaskChoices && task.type === 'place_value_zero' && (
        <>
          {effNumber !== undefined && (
            <div className="self-center bg-ws-accentSoft rounded-2xl px-8 py-4 border border-ws-accent/30">
              <span className="font-display font-black text-5xl text-ws-accent tabular-nums">{effNumber}</span>
            </div>
          )}
          <ChoiceList choices={choices} />
        </>
      )}



      {/* Guided decomposition demo (task3) */}
      {diag.showAutoUngroup && task.type === 'flexible_decomp' && (
        <div className="flex flex-col items-center gap-4">
          {effNumber !== undefined && (
            <div className="self-center bg-ws-accentSoft rounded-2xl px-8 py-4 border border-ws-accent/30">
              <span className="font-display font-black text-5xl text-ws-accent tabular-nums">{effNumber}</span>
            </div>
          )}
          <button
            onClick={demoUngroup}
            className="h-11 px-6 rounded-full font-display font-bold text-white bg-ws-accent shadow-md hover:brightness-105 active:scale-95 transition-all"
          >
            הדגם פריטה: עשרת ← 10 יחידות
          </button>
          <p className="text-sm text-ws-soft">אחרי ההדגמה, בנו את המספר בדרך חדשה ולחצו "הוסף ייצוג".</p>

          {q3Reps.length > 0 && (
            <div className="flex flex-wrap gap-2 justify-center" aria-live="polite">
              {q3Reps.map((rep, i) => (
                <span
                  key={i}
                  className="px-4 py-2 rounded-full bg-green-50 border border-ws-success text-ws-success font-bold text-sm"
                >
                  ✓ ייצוג {i + 1}: {getValue(rep).toLocaleString('he-IL')}
                </span>
              ))}
            </div>
          )}

          <button
            onClick={addRepresentation}
            disabled={done}
            className={`h-12 px-8 rounded-full font-display font-extrabold text-lg shadow-md transition-all ${
              done
                ? 'bg-ws-success text-white cursor-default'
                : 'bg-ws-accent text-white hover:brightness-105 active:scale-95'
            }`}
          >
            {done ? '✓✓ שני ייצוגים נרשמו' : `+ הוספת ייצוג (${q3Reps.length + 1}/2)`}
          </button>
        </div>
      )}

      {/* Fact-vs-procedure probe (task4) and missing_element probe (tasks 7 & 8) */}
      {effProbeA !== undefined && (task.type === 'vertical_addition' || task.type === 'missing_element') && (
        <div className="flex flex-col items-center gap-4">
          {isASD && diag.graphicOrganizerASD ? (
            /* ASD: graphic organizer instead of long text — cubes row */
            <div className="flex flex-col gap-3 w-full">
              <VisualGraphicOrganizer isSubtraction={task.isSubtraction} />
              <div className="flex justify-center items-center gap-4 bg-ws-surface2/50 rounded-2xl p-5" dir="ltr" aria-label={`${effProbeA} ${task.isSubtraction ? 'פחות' : 'ועוד'} ${effProbeB}`}>
                <div className="flex gap-1">
                  {Array.from({ length: effProbeA }).map((_, i) => (
                    <span key={i} className="w-6 h-6 rounded bg-block-unit inline-block" />
                  ))}
                </div>
                <span className="font-display font-black text-3xl text-ws-ink">{task.isSubtraction ? '-' : '+'}</span>
                <div className="flex gap-1">
                  {Array.from({ length: effProbeB ?? 0 }).map((_, i) => (
                    <span key={i} className="w-6 h-6 rounded bg-block-hundred inline-block" />
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-ws-surface2/50 rounded-2xl px-8 py-4">
              <span className="font-mono font-black text-4xl text-ws-ink tabular-nums" dir="ltr" aria-label={`תרגיל: ${effProbeA} ${task.isSubtraction ? 'פחות' : 'פלוס'} ${task.type === 'missing_element' ? 'כמה' : effProbeB} שווה ${task.type === 'missing_element' ? effProbeB : 'כמה'}`}>
                <InlineMath math={
                  task.type === 'missing_element' 
                    ? `${effProbeA} ${task.isSubtraction ? '-' : '+'} \\text{?} = ${effProbeB}`
                    : `${effProbeA} ${task.isSubtraction ? '-' : '+'} ${effProbeB} = \\text{?}`
                } />
              </span>
            </div>
          )}
          <input
            type="text"
            inputMode="numeric"
            maxLength={3}
            value={probeAnswer}
            onChange={(e) => setProbeAnswer(e.target.value.replace(/[^0-9]/g, ''))}
            aria-label="תשובה"
            className="w-24 h-16 rounded-xl border-2 border-ws-accent text-center font-mono font-black text-4xl bg-ws-surface focus:outline-none focus:ring-2"
          />
          {/* UDL Alternative Expression: Upload Draft */}
          <div className="mt-2 flex justify-center w-full">
            <label className="cursor-pointer text-sm font-bold text-ws-accent hover:text-ws-ink transition-colors flex items-center gap-2 bg-ws-surface px-4 py-2 rounded-xl shadow-sm border border-ws-ink/10">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
              העלו פתרון כתוב (תמונה)
              <input type="file" className="hidden" accept="image/*" aria-label="העלו פתרון כתמונה" onChange={() => alert("הפתרון הועלה בהצלחה למורה.")} />
            </label>
          </div>
        </div>
      )}

      {/* Flexibility-trap visual hint (q5) */}
      {diag.visualHint && task.type === 'small_change' && (
        <div className="flex flex-col gap-4">
          <div className="bg-ws-accentSoft/60 border border-ws-accent/25 rounded-2xl p-5">
            <p className="font-bold text-ws-ink leading-relaxed">💡 {diag.hintHe}</p>
          </div>
          {task.givenHe && (
            <div className="self-center bg-ws-surface2/60 rounded-2xl px-8 py-3">
              <span className="font-mono font-black text-3xl tabular-nums" dir="ltr">{task.givenHe}</span>
            </div>
          )}
          {task.questionHe && <p className="text-xl font-bold text-center">{task.questionHe}</p>}
          <ChoiceList choices={task.choices ?? []} />
        </div>
      )}
    </motion.div>
  );
}
