# Detailed Build Warning Analysis Report

## Executive Summary

During execution of `npm run build` (`tsc -b && vite build`) in `c:\Users\david\Projects\MathmatiCore\react-ts-version`, the build completed successfully with exit code 0, but generated **4 distinct build warnings** across 2 categories:

1. **TailwindCSS Ambiguous Arbitrary Class Warning** (1 log message, 2 file occurrences)
2. **Vite / Rollup Ineffective Dynamic Import Warnings** (3 log messages, across 7 files)

---

## 1. TailwindCSS Warnings

### Warning 1.1: Ambiguous `duration-[2500ms]` Class

- **Category**: CSS Utility Ambiguity / TailwindCSS v4 Compiler Warning
- **Exact Log Output**:
  ```text
  warn - The class `duration-[2500ms]` is ambiguous and matches multiple utilities.
  warn - If this is content and not a class, replace it with `duration-&lsqb;2500ms&rsqb;` to silence this warning.
  ```
- **File Locations & Line Numbers**:
  - `src/features/workspace/tasks/NumberLineTask.tsx` — Line 198:
    ```tsx
    className={`absolute top-1/2 -translate-y-1/2 transition-opacity duration-[2500ms] ${widthClass} ${heightClass} ${ ... }`}
    ```
  - `src/features/workspace/tasks/NumberLineTask.tsx` — Line 215:
    ```tsx
    className={`absolute top-[calc(50%+12px)] -translate-x-1/2 transition-opacity duration-[2500ms] text-sm font-semibold text-ws-ink tabular-nums ${isOutside ? 'opacity-30' : ''} ${visibilityClass}`}
    ```

- **Root Cause**:
  In TailwindCSS v4 (`@tailwindcss/vite`), arbitrary value classes starting with `duration-[...]` match both `transition-duration` and `animation-duration` utilities, causing the utility generator to emit an ambiguity warning.

- **Recommended Fix**:
  Replace `duration-[2500ms]` with explicit CSS property class `[transition-duration:2500ms]` (or inline style `style={{ transitionDuration: '2500ms' }}`).
  
  *Proposed Snippet for `src/features/workspace/tasks/NumberLineTask.tsx`*:
  ```tsx
  // Line 198:
  className={`absolute top-1/2 -translate-y-1/2 transition-opacity [transition-duration:2500ms] ${widthClass} ...`}

  // Line 215:
  className={`absolute top-[calc(50%+12px)] -translate-x-1/2 transition-opacity [transition-duration:2500ms] text-sm ...`}
  ```

---

## 2. Vite / Rollup Ineffective Dynamic Import Warnings

### Warning 2.1: `[INEFFECTIVE_DYNAMIC_IMPORT]` for `AuditLogger.ts`

- **Category**: Vite / Rollup Bundler Optimization Warning
- **Exact Log Output**:
  ```text
  [INEFFECTIVE_DYNAMIC_IMPORT] src/infrastructure/services/AuditLogger.ts is dynamically imported by src/features/workspace/StudentWorkspacePage.tsx, src/features/workspace/overlays/StudentChatOverlay.tsx but also statically imported by src/application/useAdminStore.ts, src/application/useAuthStore.ts, src/application/useCognitiveHesitationRadar.ts, src/application/useWorkspaceStore.ts, src/infrastructure/services/SocraticEngine.ts, dynamic import will not move module into another chunk.
  ```

- **File Locations & Line Numbers**:
  - **Dynamic Imports (Attempted Code Splitting)**:
    1. `src/features/workspace/StudentWorkspacePage.tsx` — Line 141:
       ```tsx
       import('@/infrastructure/services/AuditLogger').then(({ AuditLogger }) => {
         AuditLogger.log('TAB_ESCAPE', studentId, 'Student switched to another tab or window');
       });
       ```
    2. `src/features/workspace/overlays/StudentChatOverlay.tsx` — Line 80:
       ```tsx
       import('@/infrastructure/services/AuditLogger').then(({ AuditLogger }) => {
         AuditLogger.log( ... );
       });
       ```
  - **Static Imports (Forcing Module into Main Bundle)**:
    1. `src/application/useAdminStore.ts` — Line 2: `import { AuditLogger } from "@/infrastructure/services/AuditLogger";`
    2. `src/application/useAuthStore.ts` — Line 3: `import { AuditLogger } from "@/infrastructure/services/AuditLogger";`
    3. `src/application/useCognitiveHesitationRadar.ts` — Line 3: `import { AuditLogger } from '@/infrastructure/services/AuditLogger';`
    4. `src/application/useWorkspaceStore.ts` — Line 37: `import { AuditLogger } from '@/infrastructure/services/AuditLogger';`
    5. `src/infrastructure/services/SocraticEngine.ts` — Line 6: `import { AuditLogger } from "@/infrastructure/services/AuditLogger";`

- **Root Cause**:
  `AuditLogger` is statically imported by foundational state stores (`useWorkspaceStore`, `useAuthStore`, `useAdminStore`, `useCognitiveHesitationRadar`, `SocraticEngine`). Therefore, `AuditLogger` is already bundled into the primary module chunk. The dynamic `import(...)` calls in `StudentWorkspacePage.tsx` and `StudentChatOverlay.tsx` cannot isolate `AuditLogger` into a standalone chunk and output this warning.

- **Recommended Fix**:
  Convert the dynamic imports in `StudentWorkspacePage.tsx` and `StudentChatOverlay.tsx` to static top-level imports.

---

### Warning 2.2: `[INEFFECTIVE_DYNAMIC_IMPORT]` for `useWorkspaceStore.ts`

- **Category**: Vite / Rollup Bundler Optimization Warning
- **Exact Log Output**:
  ```text
  [INEFFECTIVE_DYNAMIC_IMPORT] src/application/useWorkspaceStore.ts is dynamically imported by src/application/useCognitiveHesitationRadar.ts but also statically imported by src/application/useStore.ts, src/features/workspace/ReflectionScreen.tsx, src/features/workspace/StudentWorkspacePage.tsx, src/features/workspace/WorkspaceTopbar.tsx, src/features/workspace/board/BlockPalette.tsx, ..., dynamic import will not move module into another chunk.
  ```

- **File Locations & Line Numbers**:
  - **Dynamic Import**:
    1. `src/application/useCognitiveHesitationRadar.ts` — Line 47:
       ```tsx
       const { useWorkspaceStore } = await import('@/application/useWorkspaceStore');
       useWorkspaceStore.setState((s: any) => ({ hesitationCount: s.hesitationCount + 1 }));
       ```
  - **Static Imports**:
    1. `src/application/useStore.ts` — Line 3: `import { useWorkspaceStore } from './useWorkspaceStore';`
    2. `src/features/workspace/ReflectionScreen.tsx` — Line 3: `import { useWorkspaceStore } from '@/application/useWorkspaceStore';`
    3. `src/features/workspace/StudentWorkspacePage.tsx` — Line 16: `import { useWorkspaceStore } from '@/application/useWorkspaceStore';`
    4. `src/features/workspace/WorkspaceTopbar.tsx` — Line 5: `import { useWorkspaceStore } from '@/application/useWorkspaceStore';`
    5. `src/features/workspace/board/BlockPalette.tsx` — Line 12: `import { useWorkspaceStore } from '@/application/useWorkspaceStore';`

- **Root Cause**:
  `useWorkspaceStore` is statically imported by almost all workspace components. Inside `useCognitiveHesitationRadar.ts`, `useWorkspaceStore` was loaded using `await import(...)` inside a timer. Since `useWorkspaceStore` is statically imported elsewhere in the workspace bundle, dynamic import has zero code-splitting effect.

- **Recommended Fix**:
  In `src/application/useCognitiveHesitationRadar.ts`:
  1. Add static import at top of file: `import { useWorkspaceStore } from '@/application/useWorkspaceStore';`
  2. Remove `await import(...)` on line 47 and invoke `useWorkspaceStore.setState(...)` directly.

---

### Warning 2.3: `[INEFFECTIVE_DYNAMIC_IMPORT]` for `SocraticEngine.ts`

- **Category**: Vite / Rollup Bundler Optimization Warning
- **Exact Log Output**:
  ```text
  [INEFFECTIVE_DYNAMIC_IMPORT] src/infrastructure/services/SocraticEngine.ts is dynamically imported by src/application/useWorkspaceStore.ts but also statically imported by src/App.tsx, src/features/workspace/StudentWorkspacePage.tsx, src/presentation/pages/TeacherDashboard.tsx, dynamic import will not move module into another chunk.
  ```

- **File Locations & Line Numbers**:
  - **Dynamic Import**:
    1. `src/application/useWorkspaceStore.ts` — Line 1225:
       ```tsx
       const { SocraticEngine } = await import('@/infrastructure/services/SocraticEngine');
       ```
  - **Static Imports**:
    1. `src/App.tsx` — Line 20: `import { SocraticEngine } from "./infrastructure/services/SocraticEngine";`
    2. `src/features/workspace/StudentWorkspacePage.tsx` — Line 40: `import { SocraticEngine } from '@/infrastructure/services/SocraticEngine';`
    3. `src/presentation/pages/TeacherDashboard.tsx` — Line 28: `import { SocraticEngine, type PendingAIApproval } from "@/infrastructure/services/SocraticEngine";`

- **Root Cause**:
  `SocraticEngine.ts` is imported statically in `App.tsx` (for window object exposure), `StudentWorkspacePage.tsx`, and `TeacherDashboard.tsx`. In `useWorkspaceStore.ts`, line 1225 uses `await import(...)` to load `SocraticEngine`. Because `SocraticEngine` is statically part of the entry bundle, this dynamic import cannot move it to a separate chunk.

- **Recommended Fix**:
  In `src/application/useWorkspaceStore.ts`:
  1. Change line 38 static import from `import type { SocraticHintResponse } from '@/infrastructure/services/SocraticEngine';` to `import { SocraticEngine, type SocraticHintResponse } from '@/infrastructure/services/SocraticEngine';`.
  2. Remove line 1225 (`const { SocraticEngine } = await import(...)`) and call `SocraticEngine.getSocraticHint(...)` directly.

---

## Verification Plan & Commands

To verify that all warnings are resolved once fixes are implemented by an Implementer agent:

1. Run full build:
   `cmd /c "npm run build"`
2. Verify output:
   - Zero `warn -` lines from Tailwind.
   - Zero `[INEFFECTIVE_DYNAMIC_IMPORT]` lines from Vite/Rollup.
   - Output string does not contain `INEFFECTIVE_DYNAMIC_IMPORT` or `ambiguous`.
