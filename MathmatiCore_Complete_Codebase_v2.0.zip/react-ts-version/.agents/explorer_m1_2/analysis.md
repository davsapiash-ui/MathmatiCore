# Comprehensive TypeScript & ESLint Static Analysis Report

**Project Root**: `c:\Users\david\Projects\MathmatiCore\react-ts-version`  
**Date**: 2026-07-27  
**Agent**: Explorer 2 (Milestone 1 — Investigation & Diagnosis)  

---

## 1. Executive Summary

Static analysis was executed across the `react-ts-version` codebase using:
1. **TypeScript Compiler (`npx tsc -p tsconfig.app.json --noEmit`)**:
   - Standard TS build (`noUnusedLocals: false`, `noUnusedParameters: false`): **0 errors, 0 warnings**.
   - Strict unused checks (`--noUnusedLocals --noUnusedParameters`): **29 compilation errors**.
2. **OX Lint / ESLint (`npm run lint` / `npx oxlint`)**:
   - Total diagnostics: **50 warnings, 0 errors** across 158 source files.
3. **Primary Warning Categories**:
   - `eslint(no-unused-vars)` / `TS6133`: 38 instances (Unused imports, local variables, parameters, catch error parameters).
   - `react-hooks(exhaustive-deps)`: 6 instances (Ref `.current` accessed in effect cleanup, missing hook dependencies).
   - `eslint(no-unassigned-vars)`: 2 instances (Declared `let` listener cleanup variables never assigned).
   - `TS6192`: 1 instance (All imports in declaration unused).

---

## 2. Static Analysis Commands & Execution Results

### Command 1: `npx oxlint` (`npm run lint`)
- **Status**: Completed (Exit Code 0)
- **Output Summary**: 50 warnings, 0 errors, 158 files scanned, 103 rules active.
- **Rule Breakdown**:
  - `eslint(no-unused-vars)`: 42 occurrences
  - `react-hooks(exhaustive-deps)`: 6 occurrences
  - `eslint(no-unassigned-vars)`: 2 occurrences

### Command 2: `npx tsc -p tsconfig.app.json --noEmit`
- **Status**: Completed (Exit Code 0 with default config).
- **With Unused Detection (`--noUnusedLocals --noUnusedParameters`)**: Failed (Exit Code 1, 29 errors).

### Command 3: `npx tsc -p tsconfig.node.json --noEmit`
- **Status**: Completed (Exit Code 0, 0 errors).

---

## 3. Categorized Warnings & Detailed Inventory

### Category A: React Hooks Dependencies & Lifecycle (`react-hooks/exhaustive-deps`)

#### 1. `src/presentation/components/ReplayViewer.tsx`
- **Line 88-92**: Direct access to `containerRef.current` inside effect cleanup function.
  - **Rule**: `react-hooks(exhaustive-deps)`
  - **Code Snippet**:
    ```tsx
    return () => {
      if (replayerRef.current) {
        try { replayerRef.current.pause(); } catch(e){}
      }
      if (containerRef.current) {
        if ((containerRef.current as any)._resizeListener) {
          window.removeEventListener('resize', (containerRef.current as any)._resizeListener);
        }
        containerRef.current.innerHTML = "";
      }
    };
    ```
  - **Issue**: The ref value `.current` may change before the effect cleanup function runs.
  - **Recommended Fix**: Copy `containerRef.current` to a local variable `const container = containerRef.current;` inside the effect, and reference `container` in cleanup.

- **Line 95**: Missing dependencies `playbackSpeed` and `onEnd` in `useEffect`.
  - **Rule**: `react-hooks(exhaustive-deps)`
  - **Code Snippet**:
    ```tsx
    replayerRef.current = new Replayer(events, {
      root: containerRef.current,
      mouseTail: false,
      speed: playbackSpeed
    });
    if (onEnd) { replayerRef.current.on('finish', onEnd); }
    // ...
    }, [events]);
    ```
  - **Issue**: `playbackSpeed` (line 35) and `onEnd` (line 42) are referenced inside the effect but omitted from the dependency array `[events]`.
  - **Recommended Fix**: Include `playbackSpeed` and `onEnd` in the dependency array or wrap `onEnd` in `useCallback` / ref if playback re-initialization should be avoided.

#### 2. `src/presentation/pages/TeacherDashboard/components/StudentReplayAndLogs.tsx`
- **Line 120**: Missing dependency `fetchChunk` in `useEffect`.
  - **Rule**: `react-hooks(exhaustive-deps)`
  - **Code Snippet**:
    ```tsx
    if (keys.length > 0) {
      fetchChunk(latestSessionId, keys[0]);
    }
    // ...
    }, [studentId]);
    ```
  - **Issue**: `useEffect` calls `fetchChunk` on line 87, but `fetchChunk` is omitted from `[studentId]`.
  - **Recommended Fix**: Wrap `fetchChunk` with `useCallback` and include it in `useEffect` dependencies `[studentId, fetchChunk]`.

- **Lines 45-46**: `unsubscribeSession` and `unsubscribeMetadata` are declared but never assigned.
  - **Rule**: `eslint(no-unassigned-vars)`
  - **Code Snippet**:
    ```tsx
    let unsubscribeSession: (() => void) | undefined;
    let unsubscribeMetadata: (() => void) | undefined;
    let unsubscribeRadar: (() => void) | undefined;
    // ...
    return () => {
      cancelled = true;
      if (unsubscribeSession) unsubscribeSession();
      if (unsubscribeMetadata) unsubscribeMetadata();
      if (unsubscribeRadar) unsubscribeRadar();
    };
    ```
  - **Issue**: Telemetry metadata is fetched via `fetch()` REST API instead of RTDB subscription, so `unsubscribeSession` and `unsubscribeMetadata` are never assigned any cleanup function.
  - **Recommended Fix**: Remove the unused `unsubscribeSession` and `unsubscribeMetadata` variables and their cleanup invocations.

---

### Category B: Unused Variables, Parameters & Imports in Application Code

#### 1. `src/application/useAdminStore.ts`
- **Line 49**: `const INITIAL_SCHOOL_ID = 'school_bikorot';` — Unused variable (`eslint(no-unused-vars)` / `TS6133`).
- **Line 50**: `const INITIAL_CLASS_ID = 'class_1';` — Unused variable (`eslint(no-unused-vars)` / `TS6133`).
- **Line 52**: `export const useAdminStore = create<AdminState>()((set) => ({` — Unused parameter `set` (`eslint(no-unused-vars)` / `TS6133`).
- **Recommended Fix**: Prefix `_set` or export constants if needed by tests, or remove unused constants/parameters.

#### 2. `src/application/useWorkspaceStore.ts`
- **Line 310**: `function startTask(taskId: string)` — Unused parameter `taskId` (`eslint(no-unused-vars)` / `TS6133`).
- **Line 829**: `const firstId = meeting === 2 ? ...` — Unused variable `firstId` (`eslint(no-unused-vars)` / `TS6133`).
- **Line 867**: `const firstId = s.sessionNumber === 2 ? ...` — Unused variable `firstId` (`eslint(no-unused-vars)` / `TS6133`).
- **Line 989**: `let isSevere = false;` — `isSevere` is assigned on line 1003 but never read (`eslint(no-unused-vars)` / `TS6133`).
- **Recommended Fix**: Remove unused `firstId` assignments, prefix `_taskId`, and utilize `isSevere` for Socratic escalation or remove.

#### 3. `src/presentation/pages/TeacherDashboard/components/HeatmapGrid.tsx`
- **Line 1**: `import React, { useState, useEffect, useMemo } from 'react';` — Unused `React` import (`TS6133`).
- **Line 4**: `import { useStore, type StudentData } from '@/application/useStore';` — Entire import is unused (`eslint(no-unused-vars)` / `TS6192`).
- **Line 11**: `Zap` — Unused import from `lucide-react` (`eslint(no-unused-vars)` / `TS6133`).
- **Line 13**: `MessageSquare` — Unused import from `lucide-react` (`eslint(no-unused-vars)` / `TS6133`).
- **Line 16**: `ChevronRight` — Unused import from `lucide-react` (`eslint(no-unused-vars)` / `TS6133`).
- **Recommended Fix**: Remove unused imports from `lucide-react` and `@/application/useStore`.

#### 4. `src/presentation/components/student/SessionReflection.tsx`
- **Line 1**: Unused `React` import (`TS6133`).
- **Line 9**: `const [selected, setSelected] = useState<number | null>(null);` — `selected` is never read (`eslint(no-unused-vars)` / `TS6133`).
- **Recommended Fix**: Remove `React` import, replace `useState` with local handle or use `selected` to highlight active selection.

#### 5. `src/presentation/components/student/EquationBoard.tsx`
- **Line 1**: Unused `React` import (`TS6133`).
- **Line 54**: `const [activeColumn, setActiveColumn] = useState<string>('units');` — `setActiveColumn` is never read (`eslint(no-unused-vars)` / `TS6133`).
- **Recommended Fix**: Prefix `_setActiveColumn` or remove state setter.

#### 6. `src/infrastructure/services/SocraticEngine.ts`
- **Line 30**: Parameter `currentTask` is unused (`TS6133`).
- **Line 32**: Parameter `counts` is unused (`eslint(no-unused-vars)` / `TS6133`).
- **Line 33**: Parameter `traceData` is unused (`eslint(no-unused-vars)` / `TS6133`).
- **Recommended Fix**: Prefix parameters with `_` (`_currentTask`, `_counts`, `_traceData`).

#### 7. `src/infrastructure/services/FirebaseSyncService.ts`
- **Line 400**: `catch (e)` — Unused catch variable `e` (`eslint(no-unused-vars)`).
- **Line 425**: `catch (e)` — Unused catch variable `e` (`eslint(no-unused-vars)`).
- **Recommended Fix**: Omit parameter `catch {}` or prefix `catch (_e)`.

#### 8. `src/features/workspace/tasks/NumberLineTask.tsx`
- **Line 187**: `const isVisible = effectiveScaffoldLevel === 0 || ...` — Unused local variable `isVisible` (`eslint(no-unused-vars)` / `TS6133`).
- **Recommended Fix**: Remove `isVisible` since `isTickVisible` is used on line 191.

#### 9. `src/features/workspace/tasks/VerticalAdditionTask.tsx`
- **Line 49**: `const [lockedClicks, setLockedClicks] = useState(0);` — Unused `lockedClicks` (`eslint(no-unused-vars)` / `TS6133`).
- **Recommended Fix**: Prefix `_lockedClicks` or remove.

#### 10. Unused `React` Imports in Components (React 19 / JSX Transform)
- `src/features/workspace/board/AdditionHelper.tsx`: line 1 (`React`)
- `src/presentation/components/student/ActivityWorkspace.tsx`: line 1 (`React`)
- `src/presentation/components/student/Session8ReflectionScreen.tsx`: line 1 (`React`)
- `src/presentation/components/student/SupportPaletteModal.tsx`: line 1 (`React`)
- `src/presentation/components/student/VirtualBlocksDock.tsx`: line 1 (`React`)
- **Recommended Fix**: Remove `React` from top-level `import React from 'react'` in React 19 JSX transform files.

---

### Category C: Unused Variables & Imports in Tests & Root Scripts

1. `src/infrastructure/__tests__/FirebaseSyncService.test.ts`:
   - Line 7: `firebaseSyncService` imported but never used.
2. `src/tests/Session8ReflectionScreen.test.tsx`:
   - Line 44: `const htmlStage1Empty` declared but never used.
   - Line 66: `catch (err)` variable `err` unused.
   - Line 132: Parameter `id` in `(id: number)` unused.
3. `tests/e2e/*.spec.ts`:
   - `prove-it.spec.ts`: line 1 `expect` unused.
   - `prove-it-v2.spec.ts`: line 1 `expect` unused.
   - `bot-run.spec.ts`: line 1 `expect` unused.
   - `bot-run-struggling.spec.ts`: line 1 `expect` unused.
   - `bot-run-average.spec.ts`: line 1 `expect` unused.
   - `multi-agent-simulation.spec.ts`: line 1 `expect`, `Page` unused; line 60 `catch (e)` unused.
4. Utility scripts:
   - `screenshot_teacher.cjs`: line 2 `path` unused.
   - `test_telemetry.js`: line 32 `catch(e)` unused.
   - `test_telemetry.cjs`: lines 1-5 `initializeApp`, `getAuth`, `signInWithEmailAndPassword`, `getDatabase`, `ref`, `get`, `firebaseConfig` unused.

---

## 4. Total Findings Summary Matrix

| Category | Finding Count | Key Files Affected | Primary Severity |
|---|---|---|---|
| Hook Lifecycle & Cleanup | 4 | `ReplayViewer.tsx` | Warning |
| Hook Dependencies | 2 | `ReplayViewer.tsx`, `StudentReplayAndLogs.tsx` | Warning |
| Unassigned Listener Variables | 2 | `StudentReplayAndLogs.tsx` | Warning |
| Unused Component State / Vars | 6 | `useWorkspaceStore.ts`, `SessionReflection.tsx`, `EquationBoard.tsx`, `VerticalAdditionTask.tsx`, `NumberLineTask.tsx` | Warning |
| Unused Imports (Lucide / Store / React) | 12 | `HeatmapGrid.tsx`, `AdditionHelper.tsx`, `ActivityWorkspace.tsx`, etc. | Warning |
| Unused Method Parameters | 5 | `SocraticEngine.ts`, `useAdminStore.ts`, `useWorkspaceStore.ts` | Warning |
| Unused Catch Parameters | 6 | `FirebaseSyncService.ts`, `ReplayViewer.tsx`, `test_telemetry.js`, etc. | Warning |
| E2E / Unit Test Unused Imports | 13 | `tests/e2e/*.spec.ts`, `Session8ReflectionScreen.test.tsx` | Warning |
| **TOTAL** | **50** | **18 Files** | **0 Errors, 50 Warnings** |

