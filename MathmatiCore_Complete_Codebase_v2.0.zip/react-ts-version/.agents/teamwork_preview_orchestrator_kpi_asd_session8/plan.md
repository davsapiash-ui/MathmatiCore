# Project Plan — MathmatiCore PRD Final Gaps Implementation & Verification

This plan details the implementation of the final three functional gaps from the MathmatiCore PRD:
1. Quantitative KPIs (Success Metrics) in Teacher Dashboard
2. ASD Digital Addition Board (student-specific toggle and workspace helper table)
3. Scaffold-Free Session 8 Test (automatically hide blocks, number lines, etc., during Session 8)

## Problem Classification & Taxonomy
- **Category**: SWE (Software Engineering) / UI-UX refactoring in React-TypeScript environment.
- **Challenge**: Integrating student settings synchronization, real-time data calculations, and adaptive layout hides in a stable Zustand/Firebase configuration.

## Architecture & Layout
- **Gaps 1 & 2 (Dashboard & Store)**:
  - Extend `StudentData` in `useStore.ts` to include `additionBoardEnabled` and calculate metrics dynamically or retrieve stored KPIs.
  - Update `FirebaseSyncService.ts` to sync the new properties.
  - Modify `TeacherDashboard.tsx` to include visual cards for the 4 metrics (Persistence, Efficiency, Estimation Accuracy, Dialogue Quality) for both selected students and in approvals.
  - Add a toggle button for "Digital Addition Board" under Accessibility settings in `TeacherCoPilotModal.tsx`.
- **Gap 2 (Student Workspace Board)**:
  - Implement `AdditionHelper.tsx` in `src/features/workspace/board/AdditionHelper.tsx`.
  - Add the `AdditionHelper` floating toggle/button to `StudentWorkspacePage.tsx` or workspace overlays, visible only when `myData?.additionBoardEnabled` is true.
- **Gap 3 (Session 8 Scaffold-Free Test)**:
  - Update `StudentWorkspacePage.tsx` and `PlaceValueBoard.tsx` to completely hide the board (Dienes blocks, BlockPalette, columns) during Session 8.
  - Update `TaskCard.tsx` and `NumberLineTask.tsx` to disable/hide the number line visual aid during Session 8.
  - Update `selectCanProceed` in `useWorkspaceStore.ts` to bypass concrete manipulative validation (Gate 1 & 1.5) when `sessionNumber === 8`, validating only the written numeric inputs.

## Milestones

| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| M0 | Exploration & Verification Setup | Analysis of components, verifying existing build runs | None | PLANNED |
| M1 | Quantitative KPIs in Teacher Dashboard | Implement 4 dynamic metrics and display them visually | M0 | PLANNED |
| M2 | ASD Digital Addition Board | Implement student toggle in teacher view andfacts table in student workspace | M1 | PLANNED |
| M3 | Scaffold-Free Session 8 Test | Hide blocks, number lines, etc. and bypass board verification in Session 8 | M2 | PLANNED |
| M4 | Build & E2E Test Verification | Run full build (`npm run build`) and test suite verification | M3 | PLANNED |
| M5 | Forensic Audit & Handoff | Conduct integrity audit checks and deliver handoff report | M4 | PLANNED |

## Verification Criteria
1. Production build `npm run build` succeeds with zero TypeScript or Vite errors.
2. All unit and Playwright E2E tests pass successfully.
3. Forensic Auditor verifies no dummy implementations, hardcoded values, or bypasses.
