## 2026-07-27T11:40:00Z
Fix the `ReferenceError: window is not defined` issue in `src/infrastructure/services/FirebaseSyncService.ts` so that unit tests (`npm run test`) pass cleanly in non-browser/Node/Vitest environments.

Tasks:
1. Open `src/infrastructure/services/FirebaseSyncService.ts` around line 337 (inside `constructor()` / listener initialization).
2. Wrap `window.addEventListener('online', ...)` and `window.addEventListener('offline', ...)` calls in a `typeof window !== 'undefined'` guard.
3. Run `cmd /c npm run test` (`npx vitest run`) and verify exit code is 0 with ALL test suites passing.
4. Run `cmd /c npm run build`, `cmd /c npx oxlint`, and `cmd /c npx tsc -p tsconfig.app.json --noEmit` to ensure zero warnings/errors remain across build, lint, and type check.
5. Create handoff report in `c:\Users\david\Projects\MathmatiCore\react-ts-version\.agents\worker_m2_2\handoff.md`.
6. Send report to parent orchestrator via `send_message`.
