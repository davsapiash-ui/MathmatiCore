## 2026-07-27T11:26:27Z
You are Worker 1 for Milestone 2 (Implementation of Fixes) of the react-ts-version clean build & zero warning project.

Your Working Directory for metadata/reports:
c:\Users\david\Projects\MathmatiCore\react-ts-version\.agents\worker_m2_1

Project Root / Working Directory for code & build:
c:\Users\david\Projects\MathmatiCore\react-ts-version

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A Forensic Auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Objective:
Implement exact, clean, non-breaking fixes for all identified Vite build warnings, Tailwind CSS class ambiguities, TypeScript issues, and ESLint / OxLint warnings in `c:\Users\david\Projects\MathmatiCore\react-ts-version`.

Detailed Task List:

1. Build & Vite Warning Fixes:
   - `src/features/workspace/tasks/NumberLineTask.tsx` (Lines 198 & 215): Replace `duration-[2500ms]` with `[transition-duration:2500ms]`. Also extend `transitionDuration: { '2500': '2500ms' }` in `tailwind.config.js` if necessary.
   - `src/features/workspace/StudentWorkspacePage.tsx` (Lines 41, 141) & `src/features/workspace/overlays/StudentChatOverlay.tsx` (Lines 10, 80): Replace dynamic `import('@/infrastructure/services/AuditLogger')` calls with top-level static imports `import { AuditLogger } from '@/infrastructure/services/AuditLogger';` and direct `AuditLogger.log(...)` calls.
   - `src/application/useCognitiveHesitationRadar.ts` (Lines 4, 47): Replace dynamic `await import('@/application/useWorkspaceStore')` with top-level static import `import { useWorkspaceStore } from '@/application/useWorkspaceStore';` and direct `useWorkspaceStore.setState(...)` call.
   - `src/application/useWorkspaceStore.ts` (Lines 38, 1225): Replace dynamic `await import('@/infrastructure/services/SocraticEngine')` with static import `import { SocraticEngine, type SocraticHintResponse } from '@/infrastructure/services/SocraticEngine';` and direct `SocraticEngine.getSocraticHint(...)` call.
   - `package.json`: Remove unused dependency `"@tailwindcss/vite": "^4.3.2"` from `dependencies`.

2. React Hook Hygiene & Dep Warnings:
   - `src/presentation/components/ReplayViewer.tsx`: Store `containerRef.current` in a local variable `const container = containerRef.current` inside `useEffect` before cleanup. Add missing dependencies `playbackSpeed` and `onEnd` to `useEffect`. Change `catch(e)` to `catch`.
   - `src/presentation/pages/TeacherDashboard/components/StudentReplayAndLogs.tsx`: Remove unassigned `unsubscribeSession` and `unsubscribeMetadata` variables and cleanup code. Wrap `fetchChunk` in `useCallback` and include in `useEffect` dependencies.

3. Static Analysis & Unused Code Cleanup:
   - `src/application/useWorkspaceStore.ts`: Remove unused `firstId` (lines 829, 867), prefix unused parameter `_taskId` (line 310), handle/remove unused `isSevere` (line 989).
   - `src/application/useAdminStore.ts`: Remove/prefix unused constants `INITIAL_SCHOOL_ID`, `INITIAL_CLASS_ID` and parameter `_set`.
   - `src/presentation/pages/TeacherDashboard/components/HeatmapGrid.tsx`: Remove unused imports (`useStore`, `StudentData`, `Zap`, `MessageSquare`, `ChevronRight`).
   - `src/infrastructure/services/SocraticEngine.ts`: Prefix unused parameters `_currentTask`, `_counts`, `_traceData`.
   - `src/infrastructure/services/FirebaseSyncService.ts`: Change `catch (e)` to `catch`.
   - `src/presentation/components/student/*.tsx`: Remove unused `import React from 'react';` from React 19 JSX files (`SessionReflection.tsx`, `EquationBoard.tsx`, `AdditionHelper.tsx`, `ActivityWorkspace.tsx`, `Session8ReflectionScreen.tsx`, `SupportPaletteModal.tsx`, `VirtualBlocksDock.tsx`).
   - `tests/e2e/*.spec.ts`: Remove unused `expect` imports.

4. Verification Requirements:
   - Run `cmd /c npm run build` and ensure exit code is 0 with ZERO warnings and ZERO `[INEFFECTIVE_DYNAMIC_IMPORT]` lines.
   - Run `cmd /c npx oxlint` and ensure ZERO warnings are reported.
   - Run `cmd /c npx tsc -p tsconfig.app.json --noEmit` to confirm clean compilation.

Instructions:
- Perform all file edits cleanly using your code editing tools.
- Create `c:\Users\david\Projects\MathmatiCore\react-ts-version\.agents\worker_m2_1\progress.md` and update it during execution.
- Create a comprehensive handoff report at `c:\Users\david\Projects\MathmatiCore\react-ts-version\.agents\worker_m2_1\handoff.md` with verbatim command execution outputs.
- Send your completed handoff report to the parent orchestrator via `send_message`.
