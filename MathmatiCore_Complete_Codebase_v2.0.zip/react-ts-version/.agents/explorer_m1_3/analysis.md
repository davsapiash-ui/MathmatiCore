# Technical Analysis: Configuration, Dynamic Imports & Tailwind Class Ambiguity

**Date**: 2026-07-27  
**Project**: `react-ts-version`  
**Author**: Explorer 3 (Milestone 1 Investigation)  

---

## Executive Summary

A comprehensive examination of project configuration files (`vite.config.ts`, `tsconfig.json`, `tsconfig.app.json`, `tsconfig.node.json`, `tailwind.config.js`, `postcss.config.js`, `package.json`) and source code in `c:\Users\david\Projects\MathmatiCore\react-ts-version` was conducted to diagnose build warnings and structural configuration issues.

The build process (`npm run build` / `tsc -b && vite build`) completes successfully in ~3.5s with zero TypeScript compilation errors. However, Vite/Rollup and Tailwind CSS emit specific warnings during transformation and chunk rendering:

1. **1x Tailwind CSS Class Ambiguity Warning**:
   - `warn - The class duration-[2500ms] is ambiguous and matches multiple utilities.`
2. **3x `[INEFFECTIVE_DYNAMIC_IMPORT]` Warnings**:
   - `src/infrastructure/services/AuditLogger.ts`
   - `src/application/useWorkspaceStore.ts`
   - `src/infrastructure/services/SocraticEngine.ts`
3. **Configuration / Dependency Version Discrepancy**:
   - Unused dependency `@tailwindcss/vite` (v4.3.2) in `package.json` while the project uses Tailwind v3.4.19 with PostCSS (`postcss.config.js`).

---

## 1. Project Configuration Analysis

### 1.1 `package.json`
- **Build & Script Commands**:
  - `"build": "tsc -b && vite build"` — uses TypeScript project references mode (`-b`), followed by Vite production bundling.
  - `"lint": "oxlint"` — fast Rust-based linter.
- **Dependency Discrepancy (Tailwind CSS v3 vs v4)**:
  - `"dependencies"` includes `@tailwindcss/vite: "^4.3.2"`.
  - `"devDependencies"` includes `tailwindcss: "^3.4.19"`, `autoprefixer: "^10.5.2"`, `postcss: "^8.5.16"`.
  - **Issue**: `@tailwindcss/vite` is a Tailwind v4 Vite plugin, but `vite.config.ts` does NOT use `@tailwindcss/vite`. Instead, `postcss.config.js` processes Tailwind via PostCSS using Tailwind v3. Leaving `@tailwindcss/vite` in `package.json` introduces dependency confusion and potential version conflicts if ever imported into Vite.

### 1.2 `vite.config.ts`
- Uses `@vitejs/plugin-react`.
- Defines alias `@` -> `./src`.
- Defines explicit Rollup `manualChunks`:
  - `rrweb` chunk for `node_modules/rrweb`
  - `recharts` chunk for `node_modules/recharts`
  - `firebase` chunk for `node_modules/firebase`
  - `vendor` chunk for other `node_modules`
- Ends with `export default defineConfig(...) as any;`.

### 1.3 TypeScript Configuration (`tsconfig.json`, `tsconfig.app.json`, `tsconfig.node.json`)
- `tsconfig.json` correctly uses Project References (`"references": [{ "path": "./tsconfig.app.json" }, { "path": "./tsconfig.node.json" }]`).
- `tsconfig.app.json`:
  - Target: `es2023`, module resolution: `bundler`, `noEmit: true`, `jsx: react-jsx`.
  - Includes `baseUrl: "."` and `paths: { "@/*": ["./src/*"] }` matching `vite.config.ts`.
  - Contains `"ignoreDeprecations": "6.0"` to silence TS 6.0 deprecation messages.

### 1.4 Tailwind & PostCSS Configuration (`tailwind.config.js`, `postcss.config.js`, `src/index.css`)
- `postcss.config.js` exports `{ plugins: { tailwindcss: {}, autoprefixer: {} } }`.
- `src/index.css` imports Google Fonts and includes `@tailwind base; @tailwind components; @tailwind utilities;`.
- `tailwind.config.js` extends custom themes:
  - Colors (`ws.*`, `block.*`, `success`, `warning`, `primary`, etc.).
  - Fonts (`Rubik`, `Heebo`, `Assistant`).
  - Border radii (`--radius`).
- **Missing Custom Extension**: `transitionDuration` is NOT extended in `tailwind.config.js`, leading components to use arbitrary value syntax `duration-[2500ms]`.

---

## 2. Deep Dive: `[INEFFECTIVE_DYNAMIC_IMPORT]` Warnings

### 2.1 Mechanism of `[INEFFECTIVE_DYNAMIC_IMPORT]` in Rollup/Vite
When Rollup analyzes module graphs for code splitting:
- An expression `import('module-path')` indicates a intent to split `module-path` into an asynchronous dynamic chunk loaded on demand.
- If `module-path` is ALSO imported statically via `import { ... } from 'module-path'` in any eager chunk (such as `App.tsx` or globally instantiated stores), Rollup MUST package `module-path` synchronously into the main entry bundle graph.
- Since `module-path` is already included synchronously in the main bundle, calling `import('module-path')` inside a function will not create a split chunk nor defer code loading.
- Rollup detects this conflict and emits `[INEFFECTIVE_DYNAMIC_IMPORT]`.

### 2.2 Detailed Breakdown of Affected Modules

#### Case A: `AuditLogger.ts`
- **Dynamic Imports**:
  - `src/features/workspace/StudentWorkspacePage.tsx:141`
  - `src/features/workspace/overlays/StudentChatOverlay.tsx:80`
- **Static Imports**:
  - `src/application/useAdminStore.ts:2`
  - `src/application/useAuthStore.ts:3`
  - `src/application/useCognitiveHesitationRadar.ts:3`
  - `src/application/useWorkspaceStore.ts:37`
  - `src/infrastructure/services/SocraticEngine.ts:6`
- **Diagnosis**: Core Zustand stores (`useAuthStore`, `useWorkspaceStore`, `useAdminStore`) statically import `AuditLogger` at top level. Because these stores are loaded synchronously when the application boots, `AuditLogger` is already bundled in the main bundle. The dynamic `import('@/infrastructure/services/AuditLogger')` calls in `StudentWorkspacePage` and `StudentChatOverlay` are redundant.

#### Case B: `useWorkspaceStore.ts`
- **Dynamic Imports**:
  - `src/application/useCognitiveHesitationRadar.ts:47`
- **Static Imports**:
  - `src/application/useStore.ts`
  - `src/features/workspace/ReflectionScreen.tsx`
  - `src/features/workspace/StudentWorkspacePage.tsx`
  - `src/features/workspace/WorkspaceTopbar.tsx`
  - `src/features/workspace/board/BlockPalette.tsx`
- **Diagnosis**: `useWorkspaceStore` is the central state management store for the workspace features and is statically imported across dozens of components. Dynamically importing `useWorkspaceStore` inside a timer inside `useCognitiveHesitationRadar.ts` provides zero bundle reduction and triggers the warning.

#### Case C: `SocraticEngine.ts`
- **Dynamic Imports**:
  - `src/application/useWorkspaceStore.ts:1225`
- **Static Imports**:
  - `src/App.tsx:20`
  - `src/features/workspace/StudentWorkspacePage.tsx`
  - `src/presentation/pages/TeacherDashboard.tsx`
- **Diagnosis**: `SocraticEngine` is statically imported in `App.tsx` (for dev/test global exposure) and in main page views (`StudentWorkspacePage`, `TeacherDashboard`). The dynamic import inside `fetchSocraticHint` in `useWorkspaceStore.ts` is ineffective.

---

## 3. Deep Dive: Tailwind CSS Class Ambiguity (`duration-[2500ms]`)

### 3.1 Cause of Warning
- **Warning**: `warn - The class duration-[2500ms] is ambiguous and matches multiple utilities.`
- **Files**: `src/features/workspace/tasks/NumberLineTask.tsx` (Lines 198 & 215).
- **Reason**: In Tailwind CSS, the `duration-` prefix maps to TWO separate utility classes:
  1. `transition-duration` (e.g. CSS `transition-duration: 2500ms;`)
  2. `animation-duration` (e.g. CSS `animation-duration: 2500ms;`)
- When Tailwind's JIT parser encounters `duration-[2500ms]`, `2500ms` is a time value that is valid for BOTH `transition-duration` and `animation-duration`. Without an explicit theme definition or type hint, Tailwind flags the class as ambiguous.

---

## 4. Proposed Fix Strategies & Refactoring Templates

### 4.1 Fix Strategy 1: Replace Ineffective Dynamic Imports with Static Imports
Convert the 3 ineffective dynamic import call sites to clean, static imports at top of file.

#### Template 1A: `src/application/useCognitiveHesitationRadar.ts`
```typescript
// Add top-level static import:
import { useWorkspaceStore } from '@/application/useWorkspaceStore';

// In timer callback (line 47):
// REPLACE: const { useWorkspaceStore } = await import('@/application/useWorkspaceStore');
// WITH: direct state update:
useWorkspaceStore.setState((s: any) => ({ hesitationCount: s.hesitationCount + 1 }));
```

#### Template 1B: `src/application/useWorkspaceStore.ts`
```typescript
// Add top-level static import:
import { SocraticEngine } from '@/infrastructure/services/SocraticEngine';

// In fetchSocraticHint (line 1225):
// REPLACE: const { SocraticEngine } = await import('@/infrastructure/services/SocraticEngine');
// WITH: direct call to SocraticEngine.getSocraticHint(...)
```

#### Template 1C: `src/features/workspace/StudentWorkspacePage.tsx` & `StudentChatOverlay.tsx`
```typescript
// Add top-level static import:
import { AuditLogger } from '@/infrastructure/services/AuditLogger';

// In event handlers:
// REPLACE: import('@/infrastructure/services/AuditLogger').then(({ AuditLogger }) => { AuditLogger.log(...); });
// WITH: AuditLogger.log(...);
```

### 4.2 Fix Strategy 2: Extend Tailwind Theme for Custom Duration
In `tailwind.config.js`:
```javascript
export default {
  // ...
  theme: {
    extend: {
      transitionDuration: {
        '2500': '2500ms',
      },
      // ...
    }
  }
}
```

In `src/features/workspace/tasks/NumberLineTask.tsx` (Lines 198 & 215):
```tsx
// REPLACE: duration-[2500ms]
// WITH: duration-2500
```

### 4.3 Fix Strategy 3: Align Dependencies in `package.json`
Remove unused `@tailwindcss/vite` from `"dependencies"` in `package.json`:
```json
// Remove: "@tailwindcss/vite": "^4.3.2",
```
This resolves the mismatch between Tailwind v3 (used via PostCSS) and Tailwind v4 Vite plugin.

---

## 5. Verification Plan

1. Execute `cmd /c npm run build`.
2. Verify that output contains ZERO `[INEFFECTIVE_DYNAMIC_IMPORT]` warnings.
3. Verify that output contains ZERO `warn - The class duration-[2500ms] is ambiguous` warnings.
4. Run tests: `cmd /c npm run test` to confirm runtime behavior remains 100% identical.
